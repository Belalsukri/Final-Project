export const setUserAction =(user)=>{
    return{
        type:'CHANE_USER',
        payload:user
    }
}